=== Coinhive WordPress ===
Contributors: brianwentzloff
Tags: coinhive, mining, cryptocurrency, monero